
AppData folder
=====================================================================

This folder can be used by all services as free space for reading and writing files.
As a best practice, all services should restrict their read/write privileges to this folder 